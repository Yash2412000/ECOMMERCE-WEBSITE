
<?php
session_start();   
// Database Connectivity
$con = mysqli_connect('localhost', 'id15134064_relsonpinto24','l(7>Yz^]&hPwXIA@');
$db = mysqli_select_db($con,'id15134064_kremlin');
if(!isset($_SESSION['username'])){
    header('location:account.php');
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>All Products - KremlinSports</title>
    <link rel="stylesheet" href="style.css " />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;600;700&display=swap"
      rel="stylesheet"
    />
  </head>
  <body style="background: radial-gradient(#fff, #ffd6d6)">
    <div class="container">
        
      <?php include "header.html"; ?>
    </div>

    <div class="small-containr container">
      <div class="row row-2">
        <h2>All Products</h2>
         <form  action="search.php" method="GET">
         <input  type ="text" placeholder="Search for Products"id="filterinput" name="filterinput"/>
      <input name="submit" type="submit"  />
   </form>
        <select class="form-control">
          <option value="Sort By">Default Sorting</option>
          <option value="Sort By Price" id="price">Sort By Price</option>
          <option value="Sort By A-Z" id="az">Sort By A-Z</option>
          <option value="Sort By Z-A" id="az">Sort By Z-A</option>
          <option>Sort by rating</option>

        </select>
        <script type="text/javascript">
  document.getElementByClass('form-control').value = "<?php echo $_GET['name'];?>";
</script>
 
      </div>

      <div class="small-container">
        <div class="row">
      <?php
            $query = "select * from M_Product sort by id ASC ";
            $query = "select * from M_Product order by id ASC ";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div class="col-4">
                        <!--Display of Products as card-->
                        <form method="post" action="cart.php?action=add&id=<?php echo $row["id"]; ?>">
                                <img src="<?php echo $row["image1"]; ?>" width="250" height="250" >
                                <h4><?php echo $row["name"]; ?></h2>
                                <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i></div>
                                <h3 style="font-family: 'Times New Roman', sans-serif;">₹ <?php echo $row["price"]; ?></h3>
                                <input type="hidden" name="name" value="<?php echo $row["name"]; ?>">
                                <input type="hidden" name="price" value="<?php echo $row["price"]; ?>">
                                <input type="hidden" name="image1" value="<?php echo $row["image1"]; ?>">
                                <input type="submit" name="AddtoCart"  class='btn' value="Add to Cart">
                        </form>
                    </div>
                    <?php
                }
            }
        ?>
        </div>
        </div>
 <div class="row"></div>
      <div class="page-btn">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>&#8594;</span>


      </div>
    </div>
    <!-- footer -->
    <?php include "footer.html"; ?>
    <!-- js for toggle menu -->
    <script>
      var MenuItems = document.getElementById("MenuItems");
      MenuItems.style.maxHeight = "0px";

      function menutoggle() {
        if (MenuItems.style.maxHeight == "0px") {
          MenuItems.style.maxHeight = "200px";
        } else {
          MenuItems.style.maxHeight = "0px";
        }
      }
    </script>
  </body>
</html>
