<?php

session_start();
//header('location:account.php');
$con = mysqli_connect('localhost', 'id15134064_relsonpinto24','l(7>Yz^]&hPwXIA@');

if($con){
mysqli_select_db($con, 'id15134064_kremlin');

$name = $_POST['UserName'];
$emai = $_POST['Email'];
$pass = $_POST['Password'];

$s =  " select * from M_User where username = '$name'";

$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num > 0 ){
    echo '<script>alert("Username already Taken")</script>';
     echo '<script>window.location.href = "account.php";</script>';
}
else{
    $reg = "insert into M_User(username, emailid, password) values('$name', '$emai', '$pass')";
    mysqli_query($con, $reg);
    echo '<script>alert("Registration Successful")</script>';
    $_SESSION['username']=$name ;
    echo '<script>window.location.href = "index.php";</script>';
    
}
}else{
    echo"No Connection";
}

?>